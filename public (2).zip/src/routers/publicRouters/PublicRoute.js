
const PublicRoute = ({ children }) => {
    return children;
};

export default PublicRoute;