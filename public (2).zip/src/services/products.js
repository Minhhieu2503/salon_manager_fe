// Danh sách sản phẩm mẫu cho Boss Barber Shop
const products = [
  {
    id: 1,
    name: 'Dầu gội xả phục hồi tóc hư tổn',
    price: 199000,
    image: 'https://cf.shopee.vn/file/sg-11134201-22110-2k1w2k2k2k2k2k',
    linkShopee: 'https://shopee.vn/product/123456/1',
  },
  {
    id: 2,
    name: 'Tinh dầu dưỡng tóc mềm mượt',
    price: 159000,
    image: 'https://cf.shopee.vn/file/sg-11134201-22110-2k1w2k2k2k2k2l',
    linkShopee: 'https://shopee.vn/product/123456/2',
  },
  {
    id: 3,
    name: 'Kem ủ tóc phục hồi chuyên sâu',
    price: 179000,
    image: 'https://cf.shopee.vn/file/sg-11134201-22110-2k1w2k2k2k2k2m',
    linkShopee: 'https://shopee.vn/product/123456/3',
  },
  // Thêm nhiều sản phẩm khác nếu cần
];

export default products; 