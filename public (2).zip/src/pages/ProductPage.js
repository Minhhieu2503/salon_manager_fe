import React, { useState } from 'react';
import products from '../services/products';

const ProductPage = () => {
  const [search, setSearch] = useState('');

  // Lọc sản phẩm theo tên
  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="product-page-container" style={{ padding: '32px', maxWidth: 1200, margin: '0 auto' }}>
      <h1 style={{ textAlign: 'center', marginBottom: 32, color: '#15397F', letterSpacing: 1, fontSize: 32, fontWeight: 700 }}>Sản phẩm Boss Barber Shop</h1>
      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 24 }}>
        <input
          type="text"
          placeholder="Tìm kiếm sản phẩm..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          style={{ padding: 12, width: '100%', maxWidth: 400, borderRadius: 12, border: '1.5px solid #15397F', fontSize: 17, outline: 'none', boxShadow: '0 1px 4px rgba(21,57,127,0.07)' }}
        />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: 32 }}>
        {filteredProducts.length === 0 ? (
          <p style={{ gridColumn: '1/-1', textAlign: 'center', color: '#888', fontSize: 18 }}>Không tìm thấy sản phẩm phù hợp.</p>
        ) : (
          filteredProducts.map(product => (
            <div
              key={product.id}
              style={{
                border: '1.5px solid #e3e8f0',
                borderRadius: 16,
                padding: 20,
                background: 'linear-gradient(135deg, #f8fafc 60%, #e3e8f0 100%)',
                boxShadow: '0 4px 16px rgba(21,57,127,0.07)',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                transition: 'box-shadow 0.2s, transform 0.2s',
                cursor: 'pointer',
                minHeight: 380,
                position: 'relative',
              }}
              onClick={() => window.open(product.linkShopee, '_blank')}
              onMouseOver={e => e.currentTarget.style.transform = 'translateY(-4px) scale(1.02)'}
              onMouseOut={e => e.currentTarget.style.transform = 'none'}
            >
              <img
                src={product.image}
                alt={product.name}
                style={{ width: 180, height: 180, objectFit: 'cover', borderRadius: 12, marginBottom: 18, boxShadow: '0 2px 8px rgba(21,57,127,0.08)' }}
              />
              <h2 style={{ fontSize: 19, fontWeight: 700, color: '#15397F', marginBottom: 10, textAlign: 'center', minHeight: 48 }}>{product.name}</h2>
              <p style={{ color: '#e53935', fontWeight: 600, fontSize: 17, marginBottom: 10 }}>{product.price.toLocaleString()} đ</p>
              <button
                style={{
                  background: 'linear-gradient(90deg, #15397F 60%, #1e88e5 100%)',
                  color: '#fff',
                  border: 'none',
                  borderRadius: 8,
                  padding: '10px 28px',
                  fontSize: 16,
                  fontWeight: 600,
                  cursor: 'pointer',
                  marginTop: 12,
                  boxShadow: '0 2px 8px rgba(21,57,127,0.10)',
                  transition: 'background 0.2s',
                }}
                onClick={e => {
                  e.stopPropagation();
                  window.open(product.linkShopee, '_blank');
                }}
              >Mua trên Shopee</button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default ProductPage; 